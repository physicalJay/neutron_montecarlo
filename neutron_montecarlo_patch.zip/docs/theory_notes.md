# Theory Notes

- Monte Carlo neutron transport model
- Collision type handling: fission, capture, scattering
- k-effective estimation via tally-based generation tracking
- Use of energy-dependent cross-sections from ENDF/B-VIII.0
- Future improvements: heterogeneous core, variance reduction
